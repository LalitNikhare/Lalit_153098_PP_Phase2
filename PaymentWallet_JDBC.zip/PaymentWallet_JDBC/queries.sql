drop table customer;
create table Customer(
	mobile_number varchar(10) primary key,
	name varchar(30),
	Balance double
);